let distance=0,currentEnv=0;
export function updateDistance(){
  distance+=0.3;
  if(Math.floor(distance)%500===0){
    currentEnv=(currentEnv+1)%3;
    scene.fog=new THREE.Fog([0xaaaaaa,0xffffff,0xffcc88][currentEnv],10,120);
  }
}