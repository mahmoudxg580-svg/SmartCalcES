export let police=new THREE.Mesh(new THREE.BoxGeometry(1,2,1), new THREE.MeshStandardMaterial({color:0x5555ff}));
scene.add(police);

export function updatePolice(player, police){
  police.position.z = player.position.z + 4;
  if(police.position.distanceTo(player.position)<1.5) gameOver();
}