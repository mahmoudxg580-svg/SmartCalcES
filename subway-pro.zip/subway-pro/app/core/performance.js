export const coinPool=[];
export function getCoin(){ return coinPool.pop() || createCoin(); }
export function recycleCoin(c){ c.visible=false; coinPool.push(c); }
export function optimize(){ renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.5)); renderer.shadowMap.enabled=false; }