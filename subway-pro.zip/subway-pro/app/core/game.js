import { chooseLane } from "./ai.js";
import { getCoin, recycleCoin } from "./performance.js";
import { submitScore } from "../systems/leaderboard.js";
import { showRewardAd } from "../systems/ads.js";
import { save, load } from "../systems/save.js";
import { missions, check } from "../systems/missions.js";

let scene = new THREE.Scene();
let camera = window.camera; // from camera.js
let renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Lights
scene.add(new THREE.AmbientLight(0xffffff,0.8));
let light = new THREE.DirectionalLight(0xffffff,1);
light.position.set(5,10,5);
scene.add(light);

// Player
let player, mixer, actions={};
let loader = new THREE.GLTFLoader();
loader.load("assets/models/player.glb",g=>{
  player=g.scene;
  mixer=new THREE.AnimationMixer(player);
  g.animations.forEach(anim=>actions[anim.name]=mixer.clipAction(anim));
  actions["Run"].play();
  scene.add(player);
  player.position.y=1;
});

// Coins
let coins=[], coinsCount=0;
for(let i=0;i<50;i++){
  let c=getCoin();
  c.position.set(([-3,0,3])[Math.floor(Math.random()*3)],1,-i*10);
  scene.add(c);
  coins.push(c);
}

// Police
import { updatePolice, police } from "../world/police.js";

// Hoverboard
let hoverboard=false;
export function activateHoverboard(){
  hoverboard=true;
  setTimeout(()=>hoverboard=false,5000);
}

// Distance & Environment
import { updateDistance } from "../world/environments.js";

// Game Loop
export function initGame(){}
export function updateGame(delta){
  if(!player) return;
  player.position.z -= 0.3;
  coins.forEach(c=>{
    c.position.z+=0.3;
    if(c.position.distanceTo(player.position)<1){
      coinsCount++;
      document.getElementById("coins").innerText=coinsCount;
      recycleCoin(c);
    }
  });
  updatePolice(player, police);
  check();
  updateDistance();
  if(mixer) mixer.update(0.016);
}