export function initInput(){
  let startX=0;
  addEventListener("touchstart",e=>startX=e.touches[0].clientX);
  addEventListener("touchend",e=>{
    let dx=e.changedTouches[0].clientX-startX;
    if(dx>50) window.moveRight();
    if(dx<-50) window.moveLeft();
  });
  addEventListener("keydown",e=>{
    if(e.key==="ArrowLeft") window.moveLeft();
    if(e.key==="ArrowRight") window.moveRight();
  });
}