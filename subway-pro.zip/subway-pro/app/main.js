import { initGame, updateGame } from "./core/game.js";
import { initInput } from "./core/input.js";
import { initCamera, updateCamera } from "./core/camera.js";
import { optimize } from "./core/performance.js";
import { initAds } from "./systems/ads.js";

initCamera();
initInput();
optimize();
initAds();
initGame();

function loop(time){
  requestAnimationFrame(loop);
  updateGame(time);
  updateCamera();
}
loop();