export function openShop(){ alert("Shop: Buy Skins / Hoverboard / Power-ups"); }
export function buy(item){ if(coins>=item.price){ coins-=item.price; inventory.push(item.id); save(); } }