export function save(){ localStorage.setItem("save",JSON.stringify({coins,inventory})); }
export function load(){ return JSON.parse(localStorage.getItem("save"))||{}; }