import { AdMob } from '@capacitor-community/admob';
export async function initAds(){ await AdMob.initialize(); }
export async function showRewardAd(){ await AdMob.showRewardVideoAd(); }