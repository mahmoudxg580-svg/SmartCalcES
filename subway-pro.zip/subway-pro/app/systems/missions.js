export let missions=[{id:1,text:"Collect 200 coins",done:false}];
export function check(){ if(coins>=200) missions[0].done=true; }