export function submitScore(score){
  fetch("https://your-server/submit",{
    method:"POST",
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({name:"Player",score})
  });
}